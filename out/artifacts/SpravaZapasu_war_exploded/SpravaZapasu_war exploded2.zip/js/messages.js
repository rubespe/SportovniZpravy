/**
 * Created by Simo on 15.6.2015.
 */
var Messages = function() {

    this.urlP = "/MessagesS";

    this.input = document.getElementById("inputDiv");
    this.list = document.getElementById("listNav");
    /******** FORMS *******/
    this.form = document.getElementById("inputForm");
    this.messagetext = document.getElementById("message");
    this.eHeader = document.getElementById("eHeader");
    this.lastId = -1;

    this.eventID = this.getParam('Event', window.location.href );
    this.eventName = this.getParam('Ename', window.location.href );

    this.eHeader.content = "Messages for event: " + this.categoryName;

    this.ws = null;
    this.formW1 = document.getElementById("SocketForm1");
    this.formW2 = document.getElementById("SocketForm2");


    this.init();

}

Messages.prototype.websocket1 = function(){
    var eId = this.eventID;
    function openSocket(){

        // Ensures only one connection is open at a time
        if(webSocket !== undefined && webSocket.readyState !== WebSocket.CLOSED){
            writeResponse("WebSocket is already opened.");
            return;
        }
        // Create a new instance of the websocket
        webSocket = new WebSocket("ws://localhost:8080/online?eventId=" + eId);



        webSocket.onopen = function(event){
            if(event.data === undefined) {
                console.log("undefined")
                return;
            }
        };

        webSocket.onmessage = function(event){
            alert("onmessage: " + event.data);
            // Message.lastId = event.data;
            Message.getAll();
        };

        webSocket.onclose = function(event){
            console.log("Connection closed");
        };
    }

    function closeSocket(){
        webSocket.close();
    }

    function writeResponse(text){
        alert( text);
    }

    openSocket();
}
var webSocket;
Messages.prototype.websocket2 = function(){
    var eId = this.eventID;
    function openSocket(){

        // Ensures only one connection is open at a time
        if(webSocket !== undefined && webSocket.readyState !== WebSocket.CLOSED){
            writeResponse("WebSocket is already opened.");
            return;
        }
        // Create a new instance of the websocket
        webSocket = new WebSocket("ws://localhost:8082/online?eventId=" + eId);



        webSocket.onopen = function(event){
            if(event.data === undefined) {
                console.log("undefined")
                return;
            }
        };

        webSocket.onmessage = function(event){
            alert("onmessage: " + event.data);
           // Message.lastId = event.data;
            Message.getAll();
        };

        webSocket.onclose = function(event){
            console.log("Connection closed");
        };
    }

    function closeSocket(){
        webSocket.close();
    }

    function writeResponse(text){
        alert( text);
    }

    openSocket();

}

Messages.prototype.getParam = function( name, url ) {
    if (!url) url = location.href
    name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
    var regexS = "[\\?&]"+name+"=([^&#]*)";
    var regex = new RegExp( regexS );
    var results = regex.exec( url );
    return results == null ? null : results[1];
}

Messages.prototype.init = function() {
    this.getAll();
    this.form.addEventListener("submit",this.submit.bind(this));
    this.formW1.addEventListener("submit",this.callW1.bind(this));
    this.formW2.addEventListener("submit",this.callW2.bind(this));
}

Messages.prototype.callW1 = function(e){
    e.preventDefault();
    console.log("W1 called");
    this.websocket1();
    console.log("W1 called");
}
Messages.prototype.callW2 = function(e){
    e.preventDefault();
    console.log("W2 called");
    this.websocket2();
    console.log("W2 called");
}

Messages.prototype.getAll = function() {
    var asyncRequest = new XMLHttpRequest();
    asyncRequest.open("GET",  this.urlP + "?Event=" + this.eventID  + "&LastId=" + this.lastId, true);    //   /Test is url to Servlet!
    res = asyncRequest.addEventListener("load", this.responseMessag.bind(this));
    asyncRequest.send();
   // alert("was sent")

}

Messages.prototype.responseMessag = function(e) {
    var x = e.target;
    if (x.readyState == 4) {
        if (x.status == 200) {
            console.log(x);
            var userIsAdmin = x.getResponseHeader ("showInput");
           // alert(userIsAdmin);
            if(userIsAdmin == "yes"){
                this.input.style.display = 'block';
            }else{
                this.input.style.display = 'none';
            }

            if (x.responseText != "") {
                res =  x.responseText;
                var p = JSON.parse(res);
                //alert("res: " + res + " " + p);

                this.addCategories(p);
                //this.getAll();
              //  alert("call getAll");
            }
        }
    }
}

Messages.prototype.addCategories = function(json){



        for (var i = 0; i < json.length; i++) {
           // this.lines.push(new Line(this, json[i]["id"],json[i]["name"]));

           // var recordA = document.createElement('div');
         //   recordA.content = "id: " +  json[i]["id"] + "\n time: " + json[i]["date"] + "\n text: " + json[i]["text"]; // Insted of calling setAttribute
            //recordA.innerHTML = json[i]["name"]; // <a>INNER_TEXT</a>

            var recordA = document.createElement('div');
            recordA.innerHTML = "<b>"+json[i]["id"]
                                +" <br/> "
                                + json[i]["date"] + " </b> "
                                +" <br/> " + json[i]["text"];

            if(json[i]["id"] > this.lastId){
                this.lastId = json[i]["id"];
            }
            recordA.style.border = "thick solid"
            recordA.style.borderWidth = "2px";
            recordA.style.borderColor = "red";


            this.list.insertBefore(recordA, this.list.firstChild);
        }


}

Messages.prototype.submit = function(e) {
    e.preventDefault();
    var error = false;

    if (this.messagetext == null || this.messagetext.value == "") {
        this.messagetext.style.border = "2px solid red";
        error = true;
    } else {
        var messagetext = this.messagetext.value;
        this.messagetext.style.border = "";
    }



    if(error == true) {
        alert("error: Text is required");
        return;
    }
    var asyncRequest = new XMLHttpRequest();

        var params = "Text=" + this.messagetext.value + "&Event=" + this.eventID ;
        asyncRequest.open("POST",  this.urlP + "?" + params, true);    //   /Test is url to Servlet!
        res = asyncRequest.addEventListener("load", this.responseAdd.bind(this));
        asyncRequest.send(params);





}

Messages.prototype.responseAdd = function(e) {
    var x = e.target;
    if (x.readyState == 4) {
        if (x.status == 200) {
            console.log(x);
            if (x.responseText != "") {
                res =  x.responseText;
                if(res != "done") {
                    alert("res: " + res);
                }
               /* if(res == null ||res == "error"){
                    alert("ERROR");
                }else if(res == "done"){*/
                   // alert("Message added");
                  //  this.list.innerHTML = "";
                   // this.getAll();

                //}
            }
        }
    }
}


var Message = new Messages();